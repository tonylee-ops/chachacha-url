package vista;

import modelo.Tema;
public class FrmMesa extends javax.swing.JFrame {
    public FrmMesa() {
        initComponents();
        personalizar();
    }

    private void personalizar() {
        Tema.aplicar(this);
        pnlProductos.setLayout(new java.awt.GridLayout(0, 4, 10, 10));
        pnlCategorias.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 4));
        Tema.ayuda(txtBuscar, "Buscar producto...");
        Tema.icono(btnConfirmar, "confirmar");
        Tema.icono(btnNota, "nota");
        Tema.icono(btnObservacion, "observacion");
        Tema.icono(btnPedirCuenta, "cuenta");
        Tema.icono(btnAnular, "anular");
        Tema.icono(btnMesas, "mesas");
        setSize(1366, 768);
        setLocationRelativeTo(null);
        setExtendedState(MAXIMIZED_BOTH);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblTitulo = new javax.swing.JLabel();
        lblMesero = new javax.swing.JLabel();
        lblEstadoMesa = new javax.swing.JLabel();
        lblCronometro = new javax.swing.JLabel();
        pnlCardPedido = new javax.swing.JPanel();
        lblSubPedido = new javax.swing.JLabel();
        lblEstadoCocina = new javax.swing.JLabel();
        lblSeleccion = new javax.swing.JLabel();
        scrDetalle = new javax.swing.JScrollPane();
        tblDetalle = new javax.swing.JTable();
        lblObservacion = new javax.swing.JLabel();
        lblCantidad = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        pnlTeclado = new javax.swing.JPanel();
        btnNum1 = new javax.swing.JButton();
        btnNum2 = new javax.swing.JButton();
        btnNum3 = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();
        btnNum4 = new javax.swing.JButton();
        btnNum5 = new javax.swing.JButton();
        btnNum6 = new javax.swing.JButton();
        btnVaciar = new javax.swing.JButton();
        btnNum7 = new javax.swing.JButton();
        btnNum8 = new javax.swing.JButton();
        btnNum9 = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnNum00 = new javax.swing.JButton();
        btnNum0 = new javax.swing.JButton();
        btnMas = new javax.swing.JButton();
        btnMenos = new javax.swing.JButton();
        pnlCardCarta = new javax.swing.JPanel();
        lblSubCarta = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        pnlCategorias = new javax.swing.JPanel();
        pnlProductos = new javax.swing.JPanel();
        btnAnterior = new javax.swing.JButton();
        lblPagina = new javax.swing.JLabel();
        btnSiguiente = new javax.swing.JButton();
        lblAyudaCarta = new javax.swing.JLabel();
        pnlAcciones = new javax.swing.JPanel();
        btnConfirmar = new javax.swing.JButton();
        btnNota = new javax.swing.JButton();
        btnObservacion = new javax.swing.JButton();
        btnPedirCuenta = new javax.swing.JButton();
        btnAnular = new javax.swing.JButton();
        btnMesas = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Don Caffeto - Mesa");

        lblTitulo.setText("Mesa");

        lblMesero.setText(" ");

        lblEstadoMesa.setText(" ");

        lblCronometro.setText("00:00");

        lblSubPedido.setText("Pedido");

        lblEstadoCocina.setText(" ");

        lblSeleccion.setText(" ");

        tblDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Cnt.", "Descripción", "Importe", " "
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDetalle.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        scrDetalle.setViewportView(tblDetalle);

        lblObservacion.setText(" ");

        lblCantidad.setText("Cantidad: 1");

        lblTotal.setText("S/ 0.00");

        btnNum1.setText("1");

        btnNum2.setText("2");

        btnNum3.setText("3");

        btnBorrar.setText("Borrar");

        btnNum4.setText("4");

        btnNum5.setText("5");

        btnNum6.setText("6");

        btnVaciar.setText("Vaciar");

        btnNum7.setText("7");

        btnNum8.setText("8");

        btnNum9.setText("9");

        btnEliminar.setText("Eliminar");

        btnNum00.setText("00");

        btnNum0.setText("0");

        btnMas.setText("+");

        btnMenos.setText("−");

        pnlTeclado.setLayout(new java.awt.GridLayout(4, 4, 6, 6));
        pnlTeclado.add(btnNum1);
        pnlTeclado.add(btnNum2);
        pnlTeclado.add(btnNum3);
        pnlTeclado.add(btnBorrar);
        pnlTeclado.add(btnNum4);
        pnlTeclado.add(btnNum5);
        pnlTeclado.add(btnNum6);
        pnlTeclado.add(btnVaciar);
        pnlTeclado.add(btnNum7);
        pnlTeclado.add(btnNum8);
        pnlTeclado.add(btnNum9);
        pnlTeclado.add(btnEliminar);
        pnlTeclado.add(btnNum00);
        pnlTeclado.add(btnNum0);
        pnlTeclado.add(btnMas);
        pnlTeclado.add(btnMenos);

        javax.swing.GroupLayout pnlCardPedidoLayout = new javax.swing.GroupLayout(pnlCardPedido);
        pnlCardPedido.setLayout(pnlCardPedidoLayout);
        pnlCardPedidoLayout.setHorizontalGroup(
            pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblSubPedido)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblEstadoCocina)
                .addGap(14, 14, 14))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblSeleccion)
                .addGap(14, 14, 14))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(scrDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblObservacion, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblCantidad)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblTotal)
                .addGap(14, 14, 14))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(pnlTeclado, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(14, 14, 14))
        );
        pnlCardPedidoLayout.setVerticalGroup(
            pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSubPedido)
                    .addComponent(lblEstadoCocina))
                .addGap(8, 8, 8)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSeleccion))
                .addGap(8, 8, 8)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblObservacion))
                .addGap(8, 8, 8)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCantidad)
                    .addComponent(lblTotal))
                .addGap(8, 8, 8)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlTeclado, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addGap(14, 14, 14))
        );

        lblSubCarta.setText("Productos");

        pnlCategorias.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 4));

        pnlProductos.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 12, 12));

        btnAnterior.setText("◀");
        btnAnterior.setToolTipText("Página anterior");

        lblPagina.setText("1 / 1");

        btnSiguiente.setText("▶");
        btnSiguiente.setToolTipText("Página siguiente");

        lblAyudaCarta.setText("Escribe la cantidad en el teclado y toca el producto");

        javax.swing.GroupLayout pnlCardCartaLayout = new javax.swing.GroupLayout(pnlCardCarta);
        pnlCardCarta.setLayout(pnlCardCartaLayout);
        pnlCardCartaLayout.setHorizontalGroup(
            pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblSubCarta)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(pnlCategorias, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(pnlProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                .addGap(14, 14, 14))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btnAnterior)
                .addGap(8, 8, 8)
                .addComponent(lblPagina)
                .addGap(8, 8, 8)
                .addComponent(btnSiguiente)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblAyudaCarta)
                .addGap(14, 14, 14))
        );
        pnlCardCartaLayout.setVerticalGroup(
            pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSubCarta)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCategorias, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAnterior)
                    .addComponent(lblPagina)
                    .addComponent(btnSiguiente)
                    .addComponent(lblAyudaCarta))
                .addGap(14, 14, 14))
        );

        btnConfirmar.setText("Confirmar");

        btnNota.setText("Nota");

        btnObservacion.setText("Observación");

        btnPedirCuenta.setText("Pedir cuenta");

        btnAnular.setText("Anular");

        btnMesas.setText("Mesas");

        pnlAcciones.setLayout(new java.awt.GridLayout(6, 1, 0, 10));
        pnlAcciones.add(btnConfirmar);
        pnlAcciones.add(btnNota);
        pnlAcciones.add(btnObservacion);
        pnlAcciones.add(btnPedirCuenta);
        pnlAcciones.add(btnAnular);
        pnlAcciones.add(btnMesas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblTitulo)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblMesero)
                .addGap(14, 14, 14)
                .addComponent(lblEstadoMesa)
                .addGap(14, 14, 14)
                .addComponent(lblCronometro)
                .addGap(16, 16, 16))
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(pnlCardPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(pnlCardCarta, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                .addGap(14, 14, 14)
                .addComponent(pnlAcciones, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTitulo)
                    .addComponent(lblMesero)
                    .addComponent(lblEstadoMesa)
                    .addComponent(lblCronometro))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCardPedido, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addComponent(pnlCardCarta, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addComponent(pnlAcciones, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE))
                .addGap(16, 16, 16))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public javax.swing.JButton getBtnAnterior() {
        return btnAnterior;
    }

    public javax.swing.JButton getBtnAnular() {
        return btnAnular;
    }

    public javax.swing.JButton getBtnBorrar() {
        return btnBorrar;
    }

    public javax.swing.JButton getBtnConfirmar() {
        return btnConfirmar;
    }

    public javax.swing.JButton getBtnEliminar() {
        return btnEliminar;
    }

    public javax.swing.JButton getBtnMas() {
        return btnMas;
    }

    public javax.swing.JButton getBtnMenos() {
        return btnMenos;
    }

    public javax.swing.JButton getBtnMesas() {
        return btnMesas;
    }

    public javax.swing.JButton getBtnNota() {
        return btnNota;
    }

    public javax.swing.JButton getBtnNum0() {
        return btnNum0;
    }

    public javax.swing.JButton getBtnNum00() {
        return btnNum00;
    }

    public javax.swing.JButton getBtnNum1() {
        return btnNum1;
    }

    public javax.swing.JButton getBtnNum2() {
        return btnNum2;
    }

    public javax.swing.JButton getBtnNum3() {
        return btnNum3;
    }

    public javax.swing.JButton getBtnNum4() {
        return btnNum4;
    }

    public javax.swing.JButton getBtnNum5() {
        return btnNum5;
    }

    public javax.swing.JButton getBtnNum6() {
        return btnNum6;
    }

    public javax.swing.JButton getBtnNum7() {
        return btnNum7;
    }

    public javax.swing.JButton getBtnNum8() {
        return btnNum8;
    }

    public javax.swing.JButton getBtnNum9() {
        return btnNum9;
    }

    public javax.swing.JButton getBtnObservacion() {
        return btnObservacion;
    }

    public javax.swing.JButton getBtnPedirCuenta() {
        return btnPedirCuenta;
    }

    public javax.swing.JButton getBtnSiguiente() {
        return btnSiguiente;
    }

    public javax.swing.JButton getBtnVaciar() {
        return btnVaciar;
    }

    public javax.swing.JLabel getLblCantidad() {
        return lblCantidad;
    }

    public javax.swing.JLabel getLblCronometro() {
        return lblCronometro;
    }

    public javax.swing.JLabel getLblEstadoCocina() {
        return lblEstadoCocina;
    }

    public javax.swing.JLabel getLblEstadoMesa() {
        return lblEstadoMesa;
    }

    public javax.swing.JLabel getLblMesero() {
        return lblMesero;
    }

    public javax.swing.JLabel getLblObservacion() {
        return lblObservacion;
    }

    public javax.swing.JLabel getLblPagina() {
        return lblPagina;
    }

    public javax.swing.JLabel getLblSeleccion() {
        return lblSeleccion;
    }

    public javax.swing.JLabel getLblTitulo() {
        return lblTitulo;
    }

    public javax.swing.JLabel getLblTotal() {
        return lblTotal;
    }

    public javax.swing.JPanel getPnlAcciones() {
        return pnlAcciones;
    }

    public javax.swing.JPanel getPnlCardCarta() {
        return pnlCardCarta;
    }

    public javax.swing.JPanel getPnlCardPedido() {
        return pnlCardPedido;
    }

    public javax.swing.JPanel getPnlCategorias() {
        return pnlCategorias;
    }

    public javax.swing.JPanel getPnlProductos() {
        return pnlProductos;
    }

    public javax.swing.JPanel getPnlTeclado() {
        return pnlTeclado;
    }

    public javax.swing.JTable getTblDetalle() {
        return tblDetalle;
    }

    public javax.swing.JTextField getTxtBuscar() {
        return txtBuscar;
    }

    public static void main(String args[]) {
        Tema.instalar();
        java.awt.EventQueue.invokeLater(() -> new FrmMesa().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnterior;
    private javax.swing.JButton btnAnular;
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMas;
    private javax.swing.JButton btnMenos;
    private javax.swing.JButton btnMesas;
    private javax.swing.JButton btnNota;
    private javax.swing.JButton btnNum0;
    private javax.swing.JButton btnNum00;
    private javax.swing.JButton btnNum1;
    private javax.swing.JButton btnNum2;
    private javax.swing.JButton btnNum3;
    private javax.swing.JButton btnNum4;
    private javax.swing.JButton btnNum5;
    private javax.swing.JButton btnNum6;
    private javax.swing.JButton btnNum7;
    private javax.swing.JButton btnNum8;
    private javax.swing.JButton btnNum9;
    private javax.swing.JButton btnObservacion;
    private javax.swing.JButton btnPedirCuenta;
    private javax.swing.JButton btnSiguiente;
    private javax.swing.JButton btnVaciar;
    private javax.swing.JLabel lblAyudaCarta;
    private javax.swing.JLabel lblCantidad;
    private javax.swing.JLabel lblCronometro;
    private javax.swing.JLabel lblEstadoCocina;
    private javax.swing.JLabel lblEstadoMesa;
    private javax.swing.JLabel lblMesero;
    private javax.swing.JLabel lblObservacion;
    private javax.swing.JLabel lblPagina;
    private javax.swing.JLabel lblSeleccion;
    private javax.swing.JLabel lblSubCarta;
    private javax.swing.JLabel lblSubPedido;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel pnlAcciones;
    private javax.swing.JPanel pnlCardCarta;
    private javax.swing.JPanel pnlCardPedido;
    private javax.swing.JPanel pnlCategorias;
    private javax.swing.JPanel pnlProductos;
    private javax.swing.JPanel pnlTeclado;
    private javax.swing.JScrollPane scrDetalle;
    private javax.swing.JTable tblDetalle;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
