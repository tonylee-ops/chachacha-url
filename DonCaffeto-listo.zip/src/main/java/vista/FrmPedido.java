package vista;

import modelo.Tema;
public class FrmPedido extends javax.swing.JFrame {
    public FrmPedido() {
        initComponents();
        personalizar();
    }

    private void personalizar() {
        Tema.aplicar(this);
        Tema.ayuda(txtBuscar, "Buscar producto...");
        Tema.ayuda(txtNota, "Nota (ej. sin azúcar)");
        Tema.ayuda(txtDireccion, "Calle, número y referencia");
        Tema.ayuda(txtTelefono, "9 dígitos");
        Tema.ayuda(txtObservacion, "Ej. cliente con apuro");
        setSize(1200, 740);
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        lblTitulo = new javax.swing.JLabel();
        lblMesero = new javax.swing.JLabel();
        pnlCardCarta = new javax.swing.JPanel();
        lblSubCarta = new javax.swing.JLabel();
        lblAyudaCarta = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        cmbCategoria = new javax.swing.JComboBox<>();
        scrProductos = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        lblEtqCantidad = new javax.swing.JLabel();
        spnCantidad = new javax.swing.JSpinner();
        txtNota = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        pnlCardPedido = new javax.swing.JPanel();
        lblSubPedido = new javax.swing.JLabel();
        lblItems = new javax.swing.JLabel();
        lblEtqModalidad = new javax.swing.JLabel();
        cmbModalidad = new javax.swing.JComboBox<>();
        lblEtqMesa = new javax.swing.JLabel();
        cmbMesa = new javax.swing.JComboBox<>();
        lblEtqDireccion = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        lblEtqTelefono = new javax.swing.JLabel();
        txtTelefono = new javax.swing.JTextField();
        scrDetalle = new javax.swing.JScrollPane();
        tblDetalle = new javax.swing.JTable();
        btnMenos = new javax.swing.JButton();
        btnMas = new javax.swing.JButton();
        btnQuitar = new javax.swing.JButton();
        lblTotal = new javax.swing.JLabel();
        lblEtqObservacion = new javax.swing.JLabel();
        txtObservacion = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Don Caffeto - Nuevo pedido");

        lblTitulo.setText("Nuevo pedido");

        lblMesero.setText("Mesero");

        lblSubCarta.setText("Carta");

        lblAyudaCarta.setText("Doble clic para agregar");

        cmbCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todas las categorías" }));

        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Producto", "Categoría", "Precio"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblProductos.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        scrProductos.setViewportView(tblProductos);

        lblEtqCantidad.setText("Cant.");

        spnCantidad.setModel(new javax.swing.SpinnerNumberModel(1, 1, 50, 1));

        btnAgregar.setText("Agregar");

        javax.swing.GroupLayout pnlCardCartaLayout = new javax.swing.GroupLayout(pnlCardCarta);
        pnlCardCarta.setLayout(pnlCardCartaLayout);
        pnlCardCartaLayout.setHorizontalGroup(
            pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblSubCarta)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblAyudaCarta)
                .addGap(18, 18, 18))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(txtBuscar, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(scrProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblEtqCantidad)
                .addGap(8, 8, 8)
                .addComponent(spnCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(txtNota, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addComponent(btnAgregar)
                .addGap(18, 18, 18))
        );
        pnlCardCartaLayout.setVerticalGroup(
            pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardCartaLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSubCarta)
                    .addComponent(lblAyudaCarta))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE))
                .addGap(10, 10, 10)
                .addGroup(pnlCardCartaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEtqCantidad)
                    .addComponent(spnCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNota, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregar))
                .addGap(18, 18, 18))
        );

        lblSubPedido.setText("Pedido");

        lblItems.setText("0 productos");

        lblEtqModalidad.setText("Modalidad");

        cmbModalidad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Salón", "Para llevar", "Delivery" }));

        lblEtqMesa.setText("Mesa");

        cmbMesa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-" }));

        lblEtqDireccion.setText("Dirección");

        lblEtqTelefono.setText("Teléfono");

        tblDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Producto", "Nota", "Cant.", "Importe"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDetalle.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        scrDetalle.setViewportView(tblDetalle);

        btnMenos.setText("−");
        btnMenos.setToolTipText("Restar una unidad");

        btnMas.setText("+");
        btnMas.setToolTipText("Sumar una unidad");

        btnQuitar.setText("Quitar");

        lblTotal.setText("S/ 0.00");

        lblEtqObservacion.setText("Observación");

        btnLimpiar.setText("Limpiar");

        btnGuardar.setText("Enviar a cocina");

        javax.swing.GroupLayout pnlCardPedidoLayout = new javax.swing.GroupLayout(pnlCardPedido);
        pnlCardPedido.setLayout(pnlCardPedidoLayout);
        pnlCardPedidoLayout.setHorizontalGroup(
            pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblSubPedido)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblItems)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblEtqModalidad, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(cmbModalidad, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addComponent(lblEtqMesa, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(cmbMesa, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblEtqDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(txtDireccion, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblEtqTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(txtTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(scrDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, 460, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(btnMenos)
                .addGap(8, 8, 8)
                .addComponent(btnMas)
                .addGap(8, 8, 8)
                .addComponent(btnQuitar)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblTotal)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblEtqObservacion, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(txtObservacion, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addGap(18, 18, 18))
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(btnLimpiar)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnGuardar)
                .addGap(18, 18, 18))
        );
        pnlCardPedidoLayout.setVerticalGroup(
            pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardPedidoLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSubPedido)
                    .addComponent(lblItems))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEtqModalidad)
                    .addComponent(cmbModalidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEtqMesa)
                    .addComponent(cmbMesa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEtqDireccion)
                    .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEtqTelefono)
                    .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scrDetalle, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMenos)
                    .addComponent(btnMas)
                    .addComponent(btnQuitar)
                    .addComponent(lblTotal))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblEtqObservacion)
                    .addComponent(txtObservacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(pnlCardPedidoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimpiar)
                    .addComponent(btnGuardar))
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblTitulo)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblMesero)
                .addGap(20, 20, 20))
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(pnlCardCarta, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(pnlCardPedido, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTitulo)
                    .addComponent(lblMesero))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCardCarta, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE)
                    .addComponent(pnlCardPedido, javax.swing.GroupLayout.DEFAULT_SIZE, 540, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public javax.swing.JButton getBtnAgregar() {
        return btnAgregar;
    }

    public javax.swing.JButton getBtnGuardar() {
        return btnGuardar;
    }

    public javax.swing.JButton getBtnLimpiar() {
        return btnLimpiar;
    }

    public javax.swing.JButton getBtnMas() {
        return btnMas;
    }

    public javax.swing.JButton getBtnMenos() {
        return btnMenos;
    }

    public javax.swing.JButton getBtnQuitar() {
        return btnQuitar;
    }

    public javax.swing.JComboBox<Object> getCmbCategoria() {
        return cmbCategoria;
    }

    public javax.swing.JComboBox<Object> getCmbMesa() {
        return cmbMesa;
    }

    public javax.swing.JComboBox<Object> getCmbModalidad() {
        return cmbModalidad;
    }

    public javax.swing.JLabel getLblEtqDireccion() {
        return lblEtqDireccion;
    }

    public javax.swing.JLabel getLblEtqMesa() {
        return lblEtqMesa;
    }

    public javax.swing.JLabel getLblEtqTelefono() {
        return lblEtqTelefono;
    }

    public javax.swing.JLabel getLblItems() {
        return lblItems;
    }

    public javax.swing.JLabel getLblMesero() {
        return lblMesero;
    }

    public javax.swing.JLabel getLblTitulo() {
        return lblTitulo;
    }

    public javax.swing.JLabel getLblTotal() {
        return lblTotal;
    }

    public javax.swing.JPanel getPnlCardCarta() {
        return pnlCardCarta;
    }

    public javax.swing.JPanel getPnlCardPedido() {
        return pnlCardPedido;
    }

    public javax.swing.JSpinner getSpnCantidad() {
        return spnCantidad;
    }

    public javax.swing.JTable getTblDetalle() {
        return tblDetalle;
    }

    public javax.swing.JTable getTblProductos() {
        return tblProductos;
    }

    public javax.swing.JTextField getTxtBuscar() {
        return txtBuscar;
    }

    public javax.swing.JTextField getTxtDireccion() {
        return txtDireccion;
    }

    public javax.swing.JTextField getTxtNota() {
        return txtNota;
    }

    public javax.swing.JTextField getTxtObservacion() {
        return txtObservacion;
    }

    public javax.swing.JTextField getTxtTelefono() {
        return txtTelefono;
    }

    public static void main(String args[]) {
        Tema.instalar();
        java.awt.EventQueue.invokeLater(() -> new FrmPedido().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnMas;
    private javax.swing.JButton btnMenos;
    private javax.swing.JButton btnQuitar;
    private javax.swing.JComboBox<Object> cmbCategoria;
    private javax.swing.JComboBox<Object> cmbMesa;
    private javax.swing.JComboBox<Object> cmbModalidad;
    private javax.swing.JLabel lblAyudaCarta;
    private javax.swing.JLabel lblEtqCantidad;
    private javax.swing.JLabel lblEtqDireccion;
    private javax.swing.JLabel lblEtqMesa;
    private javax.swing.JLabel lblEtqModalidad;
    private javax.swing.JLabel lblEtqObservacion;
    private javax.swing.JLabel lblEtqTelefono;
    private javax.swing.JLabel lblItems;
    private javax.swing.JLabel lblMesero;
    private javax.swing.JLabel lblSubCarta;
    private javax.swing.JLabel lblSubPedido;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel pnlCardCarta;
    private javax.swing.JPanel pnlCardPedido;
    private javax.swing.JScrollPane scrDetalle;
    private javax.swing.JScrollPane scrProductos;
    private javax.swing.JSpinner spnCantidad;
    private javax.swing.JTable tblDetalle;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtNota;
    private javax.swing.JTextField txtObservacion;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
}
